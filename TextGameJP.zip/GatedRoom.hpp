/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Declaration file of the GatedRoom class. Inherited 
**                  from the Space class. Includes the definitions
**                  of member functions and default constructor.
***********************************************************************/

#ifndef GATEDROOM_HPP
#define GATEDROOM_HPP

#include "Space.hpp"
#include <cstdlib>
#include <iostream>

//Definition of the GatedRoom class
class GatedRoom : public Space
{

//Data members of GatedRoom are inherited from Space
protected:
    
//member functions for the class are public to be used by programs
public:
    GatedRoom();

    void printFlavorText();
    void search(std::string *inv, int &items);
    void sneakThrough(int &hp);
    void fightMonster(std::string *inv);
};

#endif
