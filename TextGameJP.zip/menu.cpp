/***********************************************************************
** Author:          Jeff Porter
** Date:            10 April 2019
** Description:     Source file for all menu functions.
***********************************************************************/

#include "menu.hpp"


/**********************************************************************
** Description:     Default menu that takes in an array of strings that
**                  contains all of the options the user needs and the
**                  size of that array. Using these it lists all of 
**                  the options with their corresponding number. Takes
**                  input from the user, verifies it, and returns it
**                  to the place the function is called from.
**********************************************************************/
int menuDefault(std::string str[], int size)
{
    //Integer for the user's menu choice that we will be returning.
    int choice;

    //Initial menu prompt
    std::cout << "-------------------------" << std::endl;
    std::cout << "Please select one of the following:" << std::endl;
    
    //Lists all passed menu options from the string array
    for(int i = 0; i < size; i++)
    {
        std::cout << (i+1) << " : " << str[i] << std::endl;
    }
    
    std::cout << "-------------------------" << std::endl;

    //Validates the users menu choice input is correct
    do{
        std::string input;
        getline(std::cin, input);
        //Create bool assuming input is all digits (gets validated if not empty
        bool allDigit = true;

        //Checks for empty string (hits enter)
        if(!input.empty())
        {
            //Loops through input to make sure every character is a digit
            for(int i = 0; i < input.length(); i++)
            {
                if(!isdigit(input.at(i)))
                {
                    //detected a non-numeric character
                    allDigit = false;
                }
            }
        
            //based on the above digit check, evaluates the input
            if(allDigit)
            {
                //Convert the string to an integer
                choice = atoi(input.c_str());
                //Check to see if the integer is a selection
                if(choice > 0 && choice <= size)
                {
                    return choice;
                }
                else
                {
                    std::cout << "Please input an integer from the above selections." << std::endl;
                }
            }
            else
            {
                std::cout << "Please input an integer from the above selections." << std::endl;
            }
        }
        else
        {
            std::cout << "Please input an integer from the above selections." << std::endl;
        }

    }while(1);    

}

