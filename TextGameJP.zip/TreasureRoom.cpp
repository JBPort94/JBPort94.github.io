/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the TreasureRoom class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  TreasureRoom to act differently from the other Spaces.
***********************************************************************/

#include "TreasureRoom.hpp"

//Default constructor
TreasureRoom::TreasureRoom()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Treasure Room";
    monsterExists = false;
    locked = false;
    itemExists = true;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void TreasureRoom::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Treasure Room." << std::endl;
    std::cout   << "As you enter this room you notice a GIANT pile of" << std::endl
                << "gold, jewels, and treasures piled in the back. This" << std::endl
                << "is the most you've ever seen in one place by far." << std::endl
                << "Too bad you don't have your bag that you set down" << std::endl
                << "outside of the cavern. You only have your two hands" << std::endl
                << "and a pocket." << std::endl << std::endl;

    std::cout   << "The room is quite small but almost filled to the brim" << std::endl
                << "with these treasures. It's clear that the only way out" << std::endl
                << "is back the way you came. That monster must be the" << std::endl
                << "guard. Better not stay idle too long in awe, you need" << std::endl
                << "to escape and get bandaged." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the finding of the Gate Key in this room when
**                  the user chooses to search the room. Adds the 
**                  Gate Key to the user inventory array and removes it 
**                  from the room by swapping the itemExists boolean.
**********************************************************************/
void TreasureRoom::search(std::string *inv, int &items)
{
    if(itemExists == true)
    {
        std::cout   << "You decide to take a quick glance at all the treasure" << std::endl
                    << "just to indulge a bit. I mean, you only see this" << std::endl
                    << "once in a lifetime. As you look around, at the top" << std::endl
                    << "of the pile, you see a giant rusted key. It's an" << std::endl
                    << "odd item among these other great riches. It actually" << std::endl
                    << "looks like it might fit that gate in the Entrance" << std::endl
                    << "Room. You have a pocket it would fit in, it's worth" << std::endl
                    << "a shot! Climbing up to the top of the pile was not" << std::endl
                    << "an easy task. But you made it and grabbed the key." << std::endl
                    << "Is this the ticket out of here?" << std::endl;

        //Add the key to the inventory
        inv[items] = "Gate Key";
        items++;

        //Remove item from the room
        itemExists = false;
    }
    else
    {
        std::cout   << "You've already picked up the key from this room." << std::endl;
    }

    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that sneaking isn't required in
**                  this room.
**********************************************************************/
void TreasureRoom::sneakThrough(int &hp)
{
    std::cout   << "Nothing is in this room. Be discrete but no need to" << std::endl
                << "sneak around." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that there isn't any monster to
**                  fight in this room.
**********************************************************************/
void TreasureRoom::fightMonster(std::string *inv)
{
    std::cout   << "No monsters here silly." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

