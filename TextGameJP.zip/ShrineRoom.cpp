/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the ShrineRoom class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  ShrineRoom to act differently from the other Spaces.
***********************************************************************/

#include "ShrineRoom.hpp"

//Default constructor
ShrineRoom::ShrineRoom()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Shrine Room";
    monsterExists = false;
    locked = false;
    itemExists = true;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void ShrineRoom::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Shrine Room." << std::endl;
    std::cout   << "As you enter this room only one thing is apparent," << std::endl
                << "this room was made for some sort of ceremony. Along" << std::endl
                << "the back wall is a large shrine with several spikes," << std::endl
                << "treasures, and trinkets. It makes you feel queasy." << std::endl
                << "Whatever this is, it's evil and you can't be around" << std::endl
                << "it for long." << std::endl << std::endl;

    std::cout   << "The room is just a single chamber and the only way out" << std::endl
                << "is back the way you came. You have a feeling that you" << std::endl
                << "should have enver ended up here, but you need to" << std::endl
                << "escape before you lose too much blood." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the finding of the Shining Gem in this room
**                  when the user chooses to search the room. Adds the 
**                  Shining Gem to the user inventory array and removes it 
**                  from the room by swapping the itemExists boolean.
**********************************************************************/
void ShrineRoom::search(std::string *inv, int &items)
{
    if(itemExists == true)
    {
        std::cout   << "You walk up to the weird looking shrine and notice" << std::endl
                    << "an oval shaped Shining Gem at the peak of it. This" << std::endl
                    << "looks like the same shape of the slot in the stone" << std::endl
                    << "wall that trapped you inside the cave. You decide" << std::endl
                    << "grab it. It's snug but comes free with a bit of" << std::endl
                    << "effort. After taking it you feel the ground tremble" << std::endl
                    << "a bit. What was that? You decide it's not important" << std::endl
                    << "since you are running low on health and need to" << std::endl
                    << "escape as soon as possible. You have what you need," << std::endl
                    << "time to turn around and escape!" << std::endl;

        //Add the key to the inventory
        inv[items] = "Shining Gem";
        items++;

        //Remove item from the room
        itemExists = false;
    }
    else
    {
        std::cout   << "You've already picked up the Shining Gem from this room." << std::endl;
    }

    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that sneaking isn't required in
**                  this room.
**********************************************************************/
void ShrineRoom::sneakThrough(int &hp)
{
    std::cout   << "Nothing is in this room. Be discrete but no need to" << std::endl
                << "sneak around." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that there isn't any monster to
**                  fight in this room.
**********************************************************************/
void ShrineRoom::fightMonster(std::string *inv)
{
    std::cout   << "The only monster here is the history of the evil" << std::endl
                << "acts that have taken place at this shrine." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

