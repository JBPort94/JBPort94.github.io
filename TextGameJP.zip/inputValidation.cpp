/***********************************************************************
** Author:          Jeff Porter
** Date:            3 April 2019
** Description:     Source file for all data validation functions.
***********************************************************************/

#include "inputValidation.hpp"

/*
int main()
{
    int numSteps;
    std::cout << "Please enter the number of steps needed." << std::endl;
    numSteps = getPosIntLimit(100);
    
    std::cout << "Steps: " << numSteps << std::endl;

    std::cout << "Enter an integer between 100 and 500" << std::endl;
    int answer = getIntLimit(100, 500);
    std::cout << "Answer: " << answer << std::endl;

    char x = getYesOrNo();
    std::cout << "Answer: " << x << std::endl;

    return 0;
}
*/


/**********************************************************************
** Description: This function prompts the user for input. It validates
**              that the input is a positive integer. Loops until the
**              user correctly inputs a positive integer.
** Adapted from: https://stackoverflow.com/questions/32911514/validating-input-and-getline-function
***********************************************************************/
int validPositiveInt()
{
    int positiveInt;
    do{
        std::string input;
        getline(std::cin, input);
        
        if(checkNumerical(input))
        {
            positiveInt = atoi(input.c_str());
            if(positiveInt > 0)
            {
                return positiveInt;
            }
            else
            {
                std::cout << "Please input a postive integer." << std::endl;
            }
        }
        else
        {
            std::cout << "Please input a positive integer." << std::endl;
        }
    }while(1);
}


/**********************************************************************
** Description: This function prompts the user for input. It validates
**              that the input is a positive integer and under the passed
**              limit. Loops until the user inputs a valid integer.
**              
** Adapted from: https://stackoverflow.com/questions/32911514/validating-input-and-getline-function
***********************************************************************/
int getPosIntLimit(int limit)
{
    int positiveInt;
    do{
        std::string input;
        getline(std::cin, input);

        if(checkNumerical(input))
        {
            positiveInt = atoi(input.c_str());
            if(positiveInt > 0 && positiveInt <= limit)
            {
                return positiveInt;
            }
            else
            {
                std::cout << "Please input an integer between 0 and " << limit << "." << std::endl;
            }
        }
        else
        {
            std::cout << "Please input an integer between 0 and " << limit << "." << std::endl;
        }
    }while(1);
}

/**********************************************************************
** Description: This function prompts the user for input. It validates
**              that the input is an integer and between the passed
**              limits. Loops until the user inputs a valid integer.
**              
** Adapted from: https://stackoverflow.com/questions/32911514/validating-input-and-getline-function 
***********************************************************************/
int getIntLimit(int lowerLimit, int upperLimit)
{
    int validInt;
    do{
        std::string input;
        getline(std::cin, input);

        if(checkNumerical(input))
        {
            validInt = atoi(input.c_str());
            if(validInt >= lowerLimit && validInt <= upperLimit)
            {
                return validInt;
            }
            else
            {
                std::cout << "Please input an integer: " << lowerLimit << " to " << upperLimit << "." << std::endl;
            }
        }
        else
        {
            std::cout << "Please input an integer: " << lowerLimit << " to " << upperLimit << "." << std::endl;
        }
    }while(1);
}


/**********************************************************************
** Description: This function prompts the user for input. It validates
**              that the input is a character and is either Y or N.
**              Loops until the user inputs a valid character.
**              
** Adapted from: https://stackoverflow.com/questions/32911514/validating-input-and-getline-function
***********************************************************************/
char getYesOrNo()
{
    char answer;
    do{
        std::string input;
        getline(std::cin, input);

        if(input.length() == 1 && (input[0] == 'Y' || input[0] == 'N'))
        {
            answer = input[0];
            return answer;
        }
        else
        {
            std::cout << "Please input Y or N:" << std::endl;
        }

    }while(1);
}

/**********************************************************************
** Description: This is an internal function to be used by other integer
**              validation functions to check that the whole string is 
**              only digits and not empty. This then tells the other 
**              functions T/F to then further validate the int.
**
** Adapted from: http://www.cplusplus.com/reference/cctype/isdigit/
**********************************************************************/
bool checkNumerical(std::string str)
{
    if(str.empty())
    {
        //std::cout << "Empty input" << std::endl;
        return false;
    }

    for(int i = 0; i < str.length(); i++)
    {
        if (i == 0)
        {   
            if(!isdigit(str.at(i)) && str.at(i) != '-')
            {
                return false;
            }
        }
        else if(!isdigit(str.at(i)))
        {
            //std::cout << "Found a non-numerical character" << std::endl;
            return false;
        }
    }

    return true;
}

/**********************************************************************
** Description: This function prompts the user for input. It validates
**              that the input is a character and is either L or N.
**              Loops until the user inputs a valid character. 
**              Specifically made for Lab 3 and based on getYesOrNo.
**              
** Adapted from: https://stackoverflow.com/questions/32911514/validating-input-and-getline-function
***********************************************************************/
char inputDieType()
{
    char answer;
    do{
        std::string input;
        getline(std::cin, input);

        if(input.length() == 1 && (input[0] == 'L' || input[0] == 'N'))
        {
            answer = input[0];
            return answer;
        }
        else
        {
            std::cout << "Please input L (loaded) or N (normal):" << std::endl;
        }

    }while(1);
}
