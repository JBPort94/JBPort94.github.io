/***********************************************************************
** Author:          Jeff Porter
** Date:            10 April 2019
** Description:     Header file for my menu functions. This file   
**                  includes include guards and the function prototypes.
***********************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>
#include <string>

int menuDefault(std::string str[], int size);

#endif
