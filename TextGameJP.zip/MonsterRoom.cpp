/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the MonsterRoom class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  Entrance to act differently from the other Spaces.
***********************************************************************/

#include "MonsterRoom.hpp"

//Default constructor
MonsterRoom::MonsterRoom()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Monster Room";
    monsterExists = true;
    locked = false;
    itemExists = true;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void MonsterRoom::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Monster Room." << std::endl;

    //Description depends on the monster.
    if(monsterExists == true)
    {
        std::cout   << "This room is almost fully lit by torches around the" << std::endl
                    << "walls. There is one dark corner where you hear a" << std::endl
                    << "deep breathing and slight grumbling sound. Whatever" << std::endl
                    << "it is, it sounds big and dangerous. This room might" << std::endl
                    << "be bad news if you haven't anything to arm yourself" << std::endl
                    << "with." << std::endl << std::endl;
    }
    else
    {
        std::cout   << "This room is almost fully lit by torches around the" << std::endl
                    << "walls. There is still that dark corner but now that" << std::endl
                    << "you've slain the monster you are no longer worried" << std::endl
                    << "about it. This room is free and open to explore." << std::endl << std::endl;
    }

    //Room description for movement
    std::cout   << "On opposite ends of the room there are two passages." << std::endl
                << "One leads back to the entrace room and on the other" << std::endl
                << "end there is a small opening to a passage to the room" << std::endl
                << "with a golden glow." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the finding of the map in this room when
**                  the user chooses to search the room and the monster
**                  no longer exists. If it does, doesn't allow search.
**                  Adds the map to the user inventory array and removes
**                  it from the room by swapping the itemExists boolean.
**                  Describes the map to the user.
**********************************************************************/
void MonsterRoom::search(std::string *inv, int &items)
{
    if(monsterExists == false)
    {
        //Can only search if monster is taken care of
        if(itemExists == true)
        {
            std::cout   << "Behind the monster's nest you find some old" << std::endl
                        << "scratched up armor. Looks like the last person" << std::endl
                        << "here wasn't as fortunate as you were dealing with" << std::endl
                        << "the monster. Tucked away into one of the boots is" << std::endl
                        << "a piece of parchment. Unfolding it you find that" << std::endl
                        << "it looks like a map of this cavern. A red arrow is" << std::endl
                        << "drawn onto it, pointing back towards the entrance" << std::endl
                        << "room and north through the gate. What could be back" << std::endl
                        << "there?" << std::endl;

            //Add the map to the inventory
            inv[items] = "Map";
            items++;

            //Remove Item from room
            itemExists = false;
        }
        else
        {
            std::cout   << "You've already picked up the map from this room." << std::endl;
        }
    }
    else
    {
        //Can't search with a monster in the way
        std::cout   << "It's too dangerous to spend time and focus on" << std::endl
                    << "searching this room when there is some unknown" << std::endl
                    << "thing in the dark corner making scary sounds." << std::endl
                    << "You must get rid of it if you want to search." << std::endl;
    }

    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     If the monster exists, it will sneak through and 
**                  allow the user to move to the other passage, but at
**                  the cost of 10hp. If the monster doesn't exist then
**                  allows you to move freely.
**********************************************************************/
void MonsterRoom::sneakThrough(int &hp)
{
    if(monsterExists == true)
    {
        std::cout   << "You start to sneak through the room to get to" << std::endl
                    << "the other side. You try to be as quiet as possible" << std::endl
                    << "to not disturb whatever is in the corner. As" << std::endl
                    << "you get to the other side a claw barely reaches" << std::endl
                    << "you and strikes you from the back. A big gash" << std::endl
                    << "forms and starts bleeding quickly. You lose" << std::endl
                    << "10 hp." << std::endl;

        //Lose 10 HP from the monster attack
        hp = hp - 10;
    }
    else
    {
        std::cout   << "You sneak through the now empty room and make it" << std::endl
                    << "to the other side." << std::endl;
    }
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Tries to fight the monster. If the user does not 
**                  have the Sword it notifies the user that it would 
**                  not be wise to fight without a weapon. If they do,
**                  describes killing the monster then flips the bool
**                  to false so the monster no longer exists.
**********************************************************************/
void MonsterRoom::fightMonster(std::string *inv)
{
    if(monsterExists == true)
    {
        //If player has sword.
        if(inv[0] == "Sword" || inv[1] == "Sword" || inv[2] == "Sword" || inv[3] == "Sword")
        {
            std::cout   << "You decide to approach the dark corner of the room." << std::endl
                        << "As you approach you see this grotesque monster with" << std::endl
                        << "long arms and giant claws at the end of each arm." << std::endl
                        << "You notice that it is attached to a large chain" << std::endl
                        << "that seems to only be able to reach to each of" << std::endl
                        << "the passages from the room. It looks up and" << std::endl
                        << "notices you. It lunges forward and in the brief" << std::endl
                        << "moment you have before a horrible death, you" << std::endl
                        << "pick up the sword and point it at the monster." << std::endl
                        << "The monster lands on you and the sword goes" << std::endl
                        << "straight through it's abdomen. You fall to your" << std::endl
                        << "back and the lifeless monster body topples on top" << std::endl
                        << "of you. You push it to the side and get up, astonished" << std::endl
                        << "at the fact that you have just slain your first" << std::endl
                        << "monster." << std::endl;

            std::cout   << "--------------------------------------------------" << std::endl;

            //kill the monster
            monsterExists = false;
        }
        else
        {
            std::cout   << "It would not be wise to fight a monster without" << std::endl
                        << "any type of weapon." << std::endl;

            std::cout   << "--------------------------------------------------" << std::endl;
        }
    }
    else
    {
        std::cout   << "You've already slain the monster in this room." << std::endl;
        std::cout   << "--------------------------------------------------" << std::endl;
    }    
}

