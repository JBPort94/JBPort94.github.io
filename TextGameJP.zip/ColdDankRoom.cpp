/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the ColdDankRoom class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  Entrance to act differently from the other Spaces.
***********************************************************************/

#include "ColdDankRoom.hpp"

//Default constructor
ColdDankRoom::ColdDankRoom()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Cold Dank Room";
    monsterExists = false;
    locked = false;
    itemExists = true;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void ColdDankRoom::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Cold Dank Room." << std::endl;
    std::cout   << "As you enter this room you start to shiver fiercly." << std::endl
                << "You can barely see anything as it's almost pitch" << std::endl
                << "black but your eyes adjust enough to see the ground" << std::endl
                << "in front of you. You probably do not want to stay" << std::endl
                << "here long since you don't have your winter cloak" << std::endl
                << "from your bag." << std::endl << std::endl;

    std::cout   << "From the echoing of your footsteps you can clearly" << std::endl
                << "tell that this is a dead end room. No other way out" << std::endl
                << "than the way you came in. It's dark, silent, and seems" << std::endl
                << "to be long abandoned. Is it even worth exploring?" << std::endl
                << "You do need to find a way out of this cavern quickly." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the finding of the sword in this room when
**                  the user chooses to search the room. Adds the 
**                  Sword to the user inventory array and removes it 
**                  from the room by swapping the itemExists boolean.
**********************************************************************/
void ColdDankRoom::search(std::string *inv, int &items)
{
    if(itemExists == true)
    {
        std::cout   << "You stumble around in the dark kind of following" << std::endl
                    << "following the walls. As you reach toward the back" << std::endl
                    << "of the room you find a shifting stone. Pushing the" << std::endl
                    << "stone to the side, you realize that there is a" << std::endl
                    << "cache below it. Seems as if it has been already" << std::endl
                    << "accessed before as the only thing left is a rusted" << std::endl
                    << "sword. You don't have much practice with a sword," << std::endl
                    << "but this cavern is creepy. Might give you some" << std::endl
                    << "peace of mind to have some defense weapon." << std::endl;

        //Add the sword to the inventory
        inv[items] = "Sword";
        items++;

        //Remove item from the room
        itemExists = false;
    }
    else
    {
        std::cout   << "You've already picked up the sword from this room." << std::endl;
    }

    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that sneaking isn't required in
**                  this room.
**********************************************************************/
void ColdDankRoom::sneakThrough(int &hp)
{
    std::cout   << "Nothing is in this room. Be discrete but no need to" << std::endl
                << "sneak around." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that there isn't any monster to
**                  fight in this room.
**********************************************************************/
void ColdDankRoom::fightMonster(std::string *inv)
{
    std::cout   << "No monsters here silly." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

