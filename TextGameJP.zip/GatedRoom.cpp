/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the GatedRoom class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  GatedRoom to act differently from the other Spaces.
***********************************************************************/

#include "GatedRoom.hpp"

//Default constructor
GatedRoom::GatedRoom()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Gated Room";
    monsterExists = false;
    locked = true;
    itemExists = false;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void GatedRoom::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Gated Room." << std::endl;
    std::cout   << "As you walk through the gate it is quite clear that" << std::endl
                << "this is just a standard waiting room for what lies" << std::endl
                << "ahead. There is a giant door at the end of the room" << std::endl
                << "which must lead to a very important room. The door" << std::endl
                << "is covered with intricate decorations, gold trim," << std::endl
                << "and a mural of what looks to be an ancient and" << std::endl
                << "powerful type of creature. What could be through" << std::endl
                << "the door?" << std::endl;

    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the fact that there is nothing to find in
**                  this room. Lets the user know. 
**********************************************************************/
void GatedRoom::search(std::string *inv, int &items)
{
    std::cout   << "As you look around the room, you find that the" << std::endl
                << "walls are smooth and bare, the floors are clean" << std::endl
                << "and solid, and nothing is within this room besides" << std::endl
                << "the door leading to the next room." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that sneaking isn't required in
**                  this room.
**********************************************************************/
void GatedRoom::sneakThrough(int &hp)
{
    std::cout   << "Nothing is in this room. Be discrete but no need to" << std::endl
                << "sneak around." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that there isn't any monster to
**                  fight in this room.
**********************************************************************/
void GatedRoom::fightMonster(std::string *inv)
{
    std::cout   << "No monsters here silly." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

