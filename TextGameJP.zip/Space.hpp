/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Declaration file of the Space parent class. Includes 
**                  the definition of Space - all data members and
**                  public methods from implementation file.
***********************************************************************/

#ifndef SPACE_HPP
#define SPACE_HPP

#include <cstdlib>
#include <iostream>
#include <string>

//Definition of the Space class
class Space
{

//Data members of Space are made protected so child classes can access
protected:
   Space* up;
   Space* down;
   Space* left;
   Space* right;
   std::string type;
   bool monsterExists;
   bool locked;
   bool itemExists;

//member functions for the class are public to be used by programs
public:
    Space();
   
    //getters 
    std::string getType();
    bool getMonsterExists();
    bool getLocked();
    bool getItemExists();
    Space* getUp();
    Space* getDown();
    Space* getLeft();
    Space* getRight();

    //setters
    void setUp(Space* u);
    void setDown(Space* d);
    void setLeft(Space* l);
    void setRight(Space* r);
    void setLocked(bool l);

    //virtual member functions
    virtual void printFlavorText() = 0;
    virtual void search(std::string *inv, int &items) = 0;
    virtual void sneakThrough(int &hp) = 0;
    virtual void fightMonster(std::string *inv) = 0;
    virtual bool exitDungeon(std::string *inv){};

};

#endif
