/***********************************************************************
** Author:          Jeff Porter
** Date:            3 April 2019
** Description:     Header file for my input validation functions. This file   
**                  includes include guards and the function prototypes.
***********************************************************************/

#ifndef INPUTVALIDATION_HPP
#define INPUTVALIDATION_HPP

#include <iostream>
#include <string>

int validPositiveInt();
int getPosIntLimit(int);
int getIntLimit(int, int);
char getYesOrNo();
bool checkNumerical(std::string);
char inputDieType();

#endif
