/***********************************************************************
** Program Name:    Final Project - The Trapped Traveler
** Author:          Jeff Porter
** Date:            9 June 2019
** Description:     Final Project main file. Creates the Game object
**                  and then calls the appropriate functions to setup
**                  and play the game.
***********************************************************************/

#include "Game.hpp"
#include "Space.hpp"
#include "ColdDankRoom.hpp"
#include "Entrance.hpp"
#include "GatedRoom.hpp"
#include "MonsterRoom.hpp"
#include "ShrineRoom.hpp"
#include "TreasureRoom.hpp"
#include "menu.hpp"
#include "inputValidation.hpp"

#include <iostream>
#include <string>

int main()
{
    //Create the Game
    Game fun;

    //Create beginning menu.
    int mainMenuSize = 2;
    std::string mainMenu[mainMenuSize];
    mainMenu[0] = "Play Game";
    mainMenu[1] = "Quit";

    int choice = menuDefault(mainMenu, mainMenuSize);

    if(choice == 1)
    {
        //Setup the map
        fun.setupMap();
        //Play the Game
        fun.play();
    }

    return 0;
}
