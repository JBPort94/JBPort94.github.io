/***********************************************************************
** Author:          Jeff Porter
** Date:            8 June 2019
** Description:     Declaration file of the Game class. Includes the
**                  definition of Game - all private variables and public 
**                  methods from implementation file.
***********************************************************************/

#ifndef GAME_HPP
#define GAME_HPP

#include "Space.hpp"
#include "Entrance.hpp"
#include "ColdDankRoom.hpp"
#include "MonsterRoom.hpp"
#include "TreasureRoom.hpp"
#include "GatedRoom.hpp"
#include "ShrineRoom.hpp"
#include "menu.hpp"
#include "inputValidation.hpp"

#include <cstdlib>
#include <iostream>
#include <ctime>
#include <string>

//Definition of the Game class
class Game
{
//Data members of Game are kept private
private:
    int hp;
    std::string inventory[4];
    int invSize;
    int items;
    Space* currentSpace;
    Entrance entrance;
    ColdDankRoom coldDankRoom;
    MonsterRoom monsterRoom;
    TreasureRoom treasureRoom;
    GatedRoom gatedRoom;
    ShrineRoom shrineRoom;
    bool moved;
    bool winGame;

//member functions for the class are public to be used by programs
public:
    Game();

    //member functions
    void setupMap();
    void play();
    void moveRoom();
    void printStatus();

};
#endif
