/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Declaration file of the ShrineRoom class. Inherited 
**                  from the Space class. Includes the definitions
**                  of member functions and default constructor.
***********************************************************************/

#ifndef SHRINEROOM_HPP
#define SHRINEROOM_HPP

#include "Space.hpp"
#include <cstdlib>
#include <iostream>

//Definition of the ShrineRoom class
class ShrineRoom : public Space
{

//Data members of TreasureRoom are inherited from Space
protected:
    
//member functions for the class are public to be used by programs
public:
    ShrineRoom();

    void printFlavorText();
    void search(std::string *inv, int &items);
    void sneakThrough(int &hp);
    void fightMonster(std::string *inv);
};

#endif
