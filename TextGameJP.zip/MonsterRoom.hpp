/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Declaration file of the MonsterRoom class. Inherited 
**                  from the Space class. Includes the definitions
**                  of member functions and default constructor.
***********************************************************************/

#ifndef MONSTERROOM_HPP
#define MONSTERROOM_HPP

#include "Space.hpp"
#include <cstdlib>
#include <iostream>

//Definition of the MonsterRoom class
class MonsterRoom : public Space
{

//Data members of Entrance are inherited from Space
protected:
    
//member functions for the class are public to be used by programs
public:
    MonsterRoom();

    void printFlavorText();
    void search(std::string *inv, int &items);
    void sneakThrough(int &hp);
    void fightMonster(std::string *inv);
};

#endif
