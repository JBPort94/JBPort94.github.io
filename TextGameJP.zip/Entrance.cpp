/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the Entrance class. Includes 
**                  the constructor and the definitions of the virtual
**                  member functions inherited from Space. This allows
**                  Entrance to act differently from the other Spaces.
***********************************************************************/

#include "Entrance.hpp"

//Default constructor
Entrance::Entrance()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Entrance";
    monsterExists = false;
    locked = false;
    itemExists = false;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that they are now in this room
**                  and prints the flavor text and room description.
**********************************************************************/
void Entrance::printFlavorText()
{
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are in the Entrance room." << std::endl;
    std::cout   << "It is vast and enclosed but the rock walls seem to" << std::endl
                << "be laced with some mineral that gives off a natural" << std::endl
                << "glow. This allows you to see around the room." << std::endl << std::endl;

    std::cout   << "You can see four different ways to head out of this" << std::endl
                << "room. Straight ahead of the blocked exit, there is" << std::endl
                << "a giant gate blocking a passage. To the left there" << std::endl
                << "is a long passage that seems to get darker as it" << std::endl
                << "goes on. To the right there is a room with the glow" << std::endl
                << "of fire coming from it." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Describes the fact that there is nothing to find in
**                  this room. Lets the user know. 
**********************************************************************/
void Entrance::search(std::string *inv, int &items)
{
    std::cout   << "This is a pretty open and barren room. Nothing to" << std::endl
                << "find here." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that sneaking isn't required in
**                  this room.
**********************************************************************/
void Entrance::sneakThrough(int &hp)
{
    std::cout   << "Nothing is in this room. Be discrete but no need to" << std::endl
                << "sneak around." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Notifies the user that there isn't any monster to
**                  fight in this room.
**********************************************************************/
void Entrance::fightMonster(std::string *inv)
{
    std::cout   << "No monsters here silly." << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
}

/**********************************************************************
** DESCRIPTION:     Tries to exit the room. Depends on if the user has
**                  the Shining Gem or not. If they do, describes 
**                  leaving and returns true so the game can end and the
**                  user can win. If not, describes what is needed and
**                  returns false so the game continues.
**********************************************************************/
bool Entrance::exitDungeon(std::string *inv)
{
    if(inv[0] == "Shining Gem" || inv[1] == "Shining Gem" || inv[2] == "Shining Gem" || inv[3] == "Shining Gem")
    {
        std::cout   << "You find the oval shaped socket in the stone wall" << std::endl
                    << "and insert the Shining Gem into it. It's a perfect" << std::endl
                    << "fit. You step away and after a moment you hear a" << std::endl
                    << "grinding sound deep within the wall. Then the rocks" << std::endl
                    << "start shifting around and the stone wall slowly" << std::endl
                    << "raises back up, disappearing into the cave ceiling." << std::endl;
                    
        std::cout   << "--------------------------------------------------" << std::endl;
        return true;
    }
    else
    {
        std::cout   << "The stone wall is still blocking the way. There" << std::endl
                    << "doesn't seem to be a way to move it but there is" << std::endl
                    << "an oval shaped socket in the center of the wall." << std::endl
                    << "What could this be? Maybe some sort of door" << std::endl
                    << "mechanism? Maybe a natural vapor pit?" << std::endl;
        std::cout   << "--------------------------------------------------" << std::endl;

        return false;
    }
}
