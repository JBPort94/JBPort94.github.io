/***********************************************************************
** Author:          Jeff Porter
** Date:            8 June 2019
** Description:     Implementation file of the Game class. Includes 
**                  the default constructor and all member functions
**                  that make up the logic of Game by utilizing the
**                  Spaces.
***********************************************************************/

#include "Game.hpp" 

//Default constructor
Game::Game()
{
    hp = 30;
    invSize = 4;
    items = 0;
    currentSpace = &entrance;
    moved = false;
    winGame = false;
    
    for(int i = 0; i < invSize; i++)
    {
        inventory[i] = "Empty";
    }
}

/**********************************************************************
** Description:     Sets up the initial map by assigning each of the
**                  Space data members to the correct pointers of each
**                  other utilizing set functions. This links the 
**                  Spaces into a map.
**********************************************************************/
void Game::setupMap()
{
    //setup entranceRoom
    entrance.setLeft(&coldDankRoom);
    entrance.setRight(&monsterRoom);
    entrance.setUp(&gatedRoom);

    //setup coldDankRoom
    coldDankRoom.setRight(&entrance);

    //setup monsterRoom
    monsterRoom.setLeft(&entrance);
    monsterRoom.setRight(&treasureRoom);

    //setup treasureRoom
    treasureRoom.setLeft(&monsterRoom);

    //setup gatedRoom
    gatedRoom.setDown(&entrance);
    gatedRoom.setUp(&shrineRoom);

    //setup shrineRoom
    shrineRoom.setDown(&gatedRoom);
}

/**********************************************************************
** Description:     Handles the menus/logic of the main game. Introduces
**                  the player to the game. Creates the menu and handles
**                  the user's choice for each room. Continues to happen
**                  until the player escapes the cave or loses all  
**                  hp. 
**********************************************************************/
void Game::play()
{
    //Introduce the player - Setup backstory
    std::cout   << "         Welcome to The Trapped Traveler!         " << std::endl;
    std::cout   << "--------------------------------------------------" << std::endl;
    std::cout   << "You are but a simple traveler making your way from" << std::endl
                << "East Bay to the mountain town of Northengard. Night" << std::endl
                << "is coming upon you and you decide to get off the" << std::endl
                << "the road a bit to set up camp. Once you find a nice" << std::endl
                << "spot you set down your things and get ready to gather" << std::endl
                << "some fire wood. You look up and find a cavern entrance" << std::endl
                << "in the mountainside near your camp. You've always" << std::endl
                << "loved caves and thought to yourself if you can skip" << std::endl
                << "setting up the tent for a night, you'd take it! You" << std::endl
                << "walk up to the entrance and give a nice shout inside." << std::endl
                << "after no response you decide to walk inside as you can" << std::endl
                << "a dim glow from inside. As you walk inside you hear" << std::endl
                << "a loud crash and a giant stone wall comes down from" << std::endl
                << "the ceiling. As it closes you in it hits your shoulder" << std::endl
                << "and knocks you down inside. You come to quickly but" << std::endl
                << "you find that you have a large bleeding gash now." << std::endl
                << "You've been trained in medica so this would be no" << std::endl
                << "big deal to patch up if you had your gear that you" << std::endl
                << "left at the campsite. You need to get out quickly" << std::endl
                << "before you lose too much blood!" << std::endl;

    std::cout   << "--------------------------------------------------" << std::endl;

    std::cout   << "RULES: You start with 30 hp but are losing blood" << std::endl
                << "fast! With each movement between rooms the effort" << std::endl
                << "causes you to lose 1 hp. Be careful though as there" << std::endl
                << "are other dangers in this cave that could hurt you" << std::endl
                << "further." << std::endl;

    std::cout   << "--------------------------------------------------" << std::endl;
    
    do{
        //Print the current room info
        currentSpace->printFlavorText();

        //Set movement bool to false so we keep resetting the rooms interaction
        //until player leaves the room
        moved = false;

        //setup menu for room interaction
        int roomMenuSize = 4;
        std::string roomMenu[roomMenuSize];
        roomMenu[0] = "Search the room";
        roomMenu[1] = "Sneak through the room";
        roomMenu[2] = "Fight the monster in the room";
        roomMenu[3] = "Move from current room";

        //Loop through menu options until the player moves rooms
        do{    
            //Grab the room interaction from player
            int roomChoice = menuDefault(roomMenu, roomMenuSize);

            switch(roomChoice)
            {
                case 1:
                        currentSpace->search(inventory, items);
                        break;
                case 2:
                        {
                            //Need to handle the monster room differently (causing a movement)
                            if(currentSpace->getType() == "Monster Room")
                            {
                                currentSpace->sneakThrough(hp);
                                //Cause the movement after sneaking by monster
                                moveRoom();
                            }
                            else
                            {
                                currentSpace->sneakThrough(hp);
                            }
                            break;
                        }
                case 3:
                        currentSpace->fightMonster(inventory);
                        break;
                case 4:
                        {
                            //Extra condition if it's monster's room
                            if(currentSpace->getType() == "Monster Room")
                            {
                                if(currentSpace->getMonsterExists() == true)
                                {
                                    std::cout   << "You can't just walk past whatever is in that corner." << std::endl
                                                << "You must sneak by it or fight it." << std::endl;
                                }
                                else
                                {
                                    //Monster is dead, no need to sneak or fight
                                    moveRoom();
                                }
                            }
                            else
                            {
                                moveRoom();
                                //Mark that the player has moved
                            }
                            break;
                        }
            }
        }while(moved == false);

        //Player has now moved and this loop will end if the player successfully
        //exited the cavern or sadly ran out of hp - print player status
        printStatus();

    }while(winGame == false && hp > 0);

    //End of game scenario
    if(winGame == true)
    {
        //Player won by exiting the dungeon!
        std::cout   << "You have successfully made it out of the cavern!" << std::endl
                    << "You make it to your bag by the campsite and patch" << std::endl
                    << "yourself up. You're still pretty hurt but you can" << std::endl
                    << "make it to the next town to heal up at an inn. Plus" << std::endl
                    << "you want to be as far away from this creepy cave" << std::endl
                    << "as possible." << std::endl << std::endl;

        std::cout   << "                    YOU WIN!!!                    " << std::endl;
        std::cout   << "--------------------------------------------------" << std::endl;
    }
    else
    {
        //Ended due to loss of hp = player loses
        std::cout   << "You have taken too long to make it out of the cave." << std::endl
                    << "Sadly you bled too much and passed out. With the" << std::endl
                    << "cave still sealed, who knows if you'll ever be" << std::endl
                    << "found. It's the sad story of a lonely traveler." << std::endl << std::endl;

        std::cout   << "                    GAME OVER!                    " << std::endl;
        std::cout   << "--------------------------------------------------" << std::endl;
    }
}

/**********************************************************************
** Description:     Handles the movement logic of the game. Depending
**                  on which room the player is in, creates a menu
**                  of all the movement options. Grabs the users choice
**                  and moves them if possible. If not, causes the  
**                  room menu to repeat. 
**********************************************************************/
void Game::moveRoom()
{
    std::cout << "You have chosen to move to a different room." << std::endl;
    std::cout << "These are your option(s) from your current location." << std::endl;

    if(currentSpace->getType() == "Entrance")
    {
        int moveMenuSize = 4;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move up to the Gate";
        moveMenu[1] = "Move right to the room with the fire glow";
        moveMenu[2] = "Move left to the dark passage";
        moveMenu[3] = "Exit the Cavern";

        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    if(currentSpace->getUp()->getLocked() == true)
                    {
                        //Notify player of locked gate
                        std::cout   << "The Giant Gate is locked. There is a large lock" << std::endl
                                    << "that seems to need an oversized key." << std::endl;
                        std::cout   << "--------------------------------------------------" << std::endl; 

                        for(int i = 0; i < invSize; i++)
                        {
                            //Check inventory for key to unlock
                            if(inventory[i] == "Gate Key")
                            {
                                std::cout   << "Luckily you have found this giant key. You slide" << std::endl
                                            << "the key into the lock. It doesn't want to budge at" << std::endl
                                            << "at first but with some force it turns and you hear" << std::endl
                                            << "a loud click. You push the gate open with a long" << std::endl
                                            << "creaking sound." << std::endl;
                                std::cout   << "--------------------------------------------------" << std::endl;

                               //Unlock the gate
                               currentSpace->getUp()->setLocked(false); 
                            } 
                        }
                    }   
                    
                    //If the gate gets unlocked or is already unlocked
                    if(currentSpace->getUp()->getLocked() == false)
                    {
                        //Move through gate
                        currentSpace = currentSpace->getUp();
                        moved = true;
                        //Lose an hp
                        hp -= 1;
                    }
                    break;
            case 2:
                    currentSpace = currentSpace->getRight();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
            case 3:
                    currentSpace = currentSpace->getLeft();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
            case 4:
                    //Try to leave
                    winGame = currentSpace->exitDungeon(inventory);
                    //If winGame is true now, need to mark as moved
                    if(winGame == true)
                    {
                        moved = true;
                    }
                    break;
        }
    }
    else if(currentSpace->getType() == "Cold Dank Room")
    {
        int moveMenuSize = 1;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move right back to the Entrance Room";

        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    currentSpace = currentSpace->getRight();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
        }
    }
    else if(currentSpace->getType() == "Treasure Room")
    {
        int moveMenuSize = 1;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move left back to the Monster Room";

        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    currentSpace = currentSpace->getLeft();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
        }
    }
    else if(currentSpace->getType() == "Monster Room")
    {
        int moveMenuSize = 2;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move left back to the Entrance Room";
        moveMenu[1] = "Move right to the small golden passage";
        
        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    currentSpace = currentSpace->getLeft();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
            case 2:
                    currentSpace = currentSpace->getRight();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
        }
    }
    else if(currentSpace->getType() == "Gated Room")
    {
        int moveMenuSize = 2;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move down back to the Entrance Room";
        moveMenu[1] = "Move up through the giant door";

        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    currentSpace = currentSpace->getDown();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
            case 2:
                    currentSpace = currentSpace->getUp();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
        }
    }
    else if(currentSpace->getType() == "Shrine Room")
    {
        int moveMenuSize = 1;
        std::string moveMenu[moveMenuSize];
        moveMenu[0] = "Move down back to the Gated Room";

        //Grab the movement from player
        int movement = menuDefault(moveMenu, moveMenuSize);

        switch(movement)
        {
            case 1:
                    currentSpace = currentSpace->getDown();
                    moved = true;
                    //Lose an hp
                    hp -= 1;
                    break;
        }
    }
}

/**********************************************************************
** Description:     Prints the current hp of the Player. To be displayed
**                  after every move so the player knows how close to
**                  losing they are.
**********************************************************************/
void Game::printStatus()
{
    std::cout   << "Current Player Status: " << std::endl
                << "HP = ";
   
    if (hp <= 0)
    {
        std::cout   << "0!" << std::endl;
    }
    else
    {
        std::cout   << hp << "!" << std::endl;
    }

    std::cout   << "--------------------------------------------------" << std::endl;
}
