/***********************************************************************
** Author:          Jeff Porter
** Date:            6 June 2019
** Description:     Implementation file of the Space class. Includes the 
**                  set/get functions for child classes to use.
**                  
***********************************************************************/

#include "Space.hpp"

//Default constructor
Space::Space()
{
    up = nullptr;
    down = nullptr;
    left = nullptr;
    right = nullptr;
    type = "Space";
    monsterExists = false;
    locked = false;
    itemExists = false;
}

//Getters
std::string Space::getType()
{
    return type;
}

bool Space::getMonsterExists()
{
    return monsterExists;
}

bool Space::getLocked()
{
    return locked;
}

bool Space::getItemExists()
{
    return itemExists;
}

Space* Space::getUp()
{
    return up;
}

Space* Space::getDown()
{
    return down;
}

Space* Space::getLeft()
{
    return left;
}

Space* Space::getRight()
{
    return right;
}

//Setters
void Space::setUp(Space* u)
{
    up = u;
}

void Space::setDown(Space* d)
{
    down = d;
}

void Space::setLeft(Space* l)
{
    left = l;
}

void Space::setRight(Space* r)
{
    right = r;
}

void Space::setLocked(bool l)
{
    locked = l;
}

