//script.js
//Author: Jeff Porter
//Date: 2/9/2020
//CS 290 - 400
//Homework 4

//REQUIRED FUNCTIONS
function buildTable(){
    var tableBody = document.createElement("table");

    //style the table
    tableBody.style.border = "2px solid black";

    //Create the Header Row
    var tableHR = document.createElement("tr");

    //Create the header elements
    for(var i = 0; i < 4; i++){
        var headerCell = document.createElement("th");

        headerCell.textContent = ("Header " + (i+1));
        headerCell.style.height = "80px";
        headerCell.style.width = "160px";
        headerCell.style.textAlign = "center";
        headerCell.style.border = "2px solid black";
        headerCell.style.backgroundColor = "lightblue"

        //Append the header element
        tableHR.appendChild(headerCell);
    }   

    //Append the header row
    tableBody.appendChild(tableHR);

    //Create the 3 other Rows
    for(var i = 0; i < 3; i++){
        //Create the row
        var tableRow = document.createElement("tr");

        //Create the 4 cells in the row
        for(var j = 0; j < 4; j++){
            var rowCell = document.createElement("td");

            //Style the element
            rowCell.textContent = ((i+1) + ", " + (j+1));
            rowCell.id = (i+1) + "" + (j+1);
            rowCell.style.height = "80px";
            rowCell.style.width = "160px";
            rowCell.style.textAlign = "center";
            rowCell.style.border = "1px solid darkgray";

            //Append the element
            tableRow.appendChild(rowCell);
        }

        //Append row
        tableBody.appendChild(tableRow);
    }

    return tableBody;
}

//Change current cell back to normal, move location, then apply thick border to new location
function moveUp(){
    //Check to make sure we aren't already in up most location
    if(currentLocation[0] > 1){
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "1px solid darkgray";
        currentLocation[0]--;
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "4px solid black";
    }
    return;
}

//Change current cell back to normal, move location, then apply thick border to new location
function moveDown(){
    //Check to make sure we aren't already in down most location
    if(currentLocation[0] < 3){
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "1px solid darkgray";
        currentLocation[0]++;
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "4px solid black";
    }
    return;
}

//Change current cell back to normal, move location, then apply thick border to new location
function moveLeft(){
    //Check to make sure we aren't already in left most location
    if(currentLocation[1] > 1){
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "1px solid darkgray";
        currentLocation[1]--;
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "4px solid black";
    }
    return;
}

//Change current cell back to normal, move location, then apply thick border to new location
function moveRight(){
    //Check to make sure we aren't already in right most location
    if(currentLocation[1] < 4){
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "1px solid darkgray";
        currentLocation[1]++;
        document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "4px solid black";
    }
    return;
}

function markCell(){
    document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.backgroundColor = "yellow";
}

//PAGE BUILD
var body = document.body;
var table = buildTable();

//Buttons - style and click events
var upButton = document.createElement("button");
upButton.textContent = "Up";
upButton.style.width = "100px";
upButton.style.height = "50px";
upButton.style.margin = "10px";
upButton.addEventListener("click", moveUp);

var downButton = document.createElement("button");
downButton.textContent = "Down";
downButton.style.width = "100px";
downButton.style.height = "50px";
downButton.style.margin = "10px";
downButton.addEventListener("click", moveDown);

var leftButton = document.createElement("button");
leftButton.textContent = "Left";
leftButton.style.width = "100px";
leftButton.style.height = "50px";
leftButton.style.margin = "10px";
leftButton.addEventListener("click", moveLeft);

var rightButton = document.createElement("button");
rightButton.textContent = "Right";
rightButton.style.width = "100px";
rightButton.style.height = "50px";
rightButton.style.margin = "10px";
rightButton.addEventListener("click", moveRight);

var markButton = document.createElement("button");
markButton.textContent = "Mark Cell";
markButton.style.width = "100px";
markButton.style.height = "50px";
markButton.style.margin = "10px";
markButton.style.backgroundColor = "lightGreen";
markButton.addEventListener("click", markCell);

//Appending all objects
body.appendChild(table);
body.appendChild(upButton);
body.appendChild(downButton);
body.appendChild(leftButton);
body.appendChild(rightButton);
body.appendChild(markButton);

//start in the first cell
var currentLocation = [1, 1];
document.getElementById(currentLocation[0] + "" + currentLocation[1]).style.border = "4px solid black";